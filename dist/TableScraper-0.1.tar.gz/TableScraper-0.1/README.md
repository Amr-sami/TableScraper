# Web Scraping Tool

This Python tool extracts tables from a webpage and saves them as CSV files.

## Installation

```bash
pip install TableScraper
